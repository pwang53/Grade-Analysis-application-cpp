/*main.cpp*/

//
// Peiqi Wang
// U. of Illinois, Chicago
// CS 341, Fall 2019
// Project #03: GradeUtil UI
// This program is C++11 dependent
//

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>
#include <stdlib.h>
#include <math.h>
#include <map>
#include <functional>
using namespace std;

// includes for gradeutil
#include "gradeutil.h"

College InputGradeData(string filename)
{
    College college;
    ifstream file(filename);
    string line, value;

    if (!file.good())
    {
        cout << "**Error: unable to open input file '" << filename << "'." << endl;
        return college;
    }

    // first line contains semester,year
    getline(file, line);
    stringstream ss(line);

    getline(ss, college.Name, ',');
    getline(ss, college.Semester, ',');
    getline(ss, value);
    college.Year = stoi(value);

    // second line contains column headers --- skip
    getline(file, line);

    //
    // now start inputting and parse course data:
    //

    while (getline(file, line))
    {
        Course c = ParseCourse(line);

        //
        // search for correct dept to ask course to, otherwise create a new dept:
        //
        auto dept_iter = std::find_if(college.Depts.begin(),
                                      college.Depts.end(),
                                      [&](const Dept &d) {
                                          return (d.Name == c.Dept);
                                      });

        if (dept_iter == college.Depts.end())
        {
            //
            // doesn't exist, so we have to create a new dept
            // and insert course:
            //
            Dept d(c.Dept);

            d.Courses.push_back(c);

            college.Depts.push_back(d);
        }
        else
        {
            // dept exists, so insert course into existing dept:
            dept_iter->Courses.push_back(c);
        }

    } //while

    //
    // done:
    //
    return college;
}

// TODO: define your own functions
//
//


void call_print1(College college) {
    int DFW, N;  
    double collegeDFW = GetDFWRate(college, DFW, N);
  
    GradeStats status = GetGradeDistribution(college);
  
    cout << "# of courses taught: " << college.NumCourses() << endl;
    cout << "# of students taught: " << college.NumStudents() << endl;
    cout << "grade distribution (A-F): " << status.PercentA << "%, " 
         << status.PercentB << "%, " << status.PercentC << "%, "
         << status.PercentD << "%, " << status.PercentF << "% " << endl;
    cout << "DFW rate: " << collegeDFW << "%" << endl;
}

void call_print2(Dept dept) {
    int DFW, N;  
    double deptDFW = GetDFWRate(dept, DFW, N);
  
    GradeStats status = GetGradeDistribution(dept);
    
    cout << " # courses taught: " << dept.NumCourses() << endl;
    cout << " # students taught: " << dept.NumStudents() << endl;
    cout << " grade distribution (A-F): " << status.PercentA << "%, " 
         << status.PercentB << "%, " << status.PercentC << "%, "
         << status.PercentD << "%, " << status.PercentF << "% " << endl;
    cout << " DFW rate: " << deptDFW << "%" << endl;  
}

void call_print3(Course c) {
    int DFW, N;
    double courseDFW = GetDFWRate(c, DFW, N);
    
    GradeStats status = GetGradeDistribution(c);
    int i = c.getGradingType();
  
    cout << c.Dept << " " << c.Number << " (section " << c.Section << "): " << c.Instructor << endl;
    cout << " # students: " << c.getNumStudents() << endl;
    if(i == 0) cout << " course type: letter"<< endl;
    if(i == 1) cout << " course type: satisfactory"<< endl;
    if(i == 2) cout << " course type: unknown"<< endl;
    cout << " grade distribution (A-F): " << status.PercentA << "%, " 
         << status.PercentB << "%, " << status.PercentC << "%, "
         << status.PercentD << "%, " << status.PercentF << "% " << endl;
    cout << " DFW rate: " << courseDFW << "%" << endl;  
}

void sort_in_order(College& college) {
  std::sort(college.Depts.begin(), college.Depts.end(), 
            [](const Dept& d1, const Dept& d2){
               if(d1.Name < d2.Name) {
                 return true;
               }
               else {
                 return false;
               }
            });  
}

void sort_back_order(vector<Course> &course) {
    
    std::sort(course.begin(), course.end(), 
            [](const Course& c1, const Course& c2){
              int a,b;
              double dfw1 = GetDFWRate(c1, a, b);
              double dfw2 = GetDFWRate(c2, a, b);
              if(dfw1 > dfw2) {
                 return true;
               }
               else {
                 return false;
               }
            }); 
}

void sort_back_order2(vector<Course> &course) {
    
    std::sort(course.begin(), course.end(), 
            [](const Course& c1, const Course& c2){
              GradeStats status1 = GetGradeDistribution(c1);
              GradeStats status2 = GetGradeDistribution(c2);
              if(status1.PercentB > status2.PercentB) {
                 return true;
               }
               else {
                 return false;
               }
            }); 
}


void sort_number_in_order(vector<Course> &course) {
  std::sort(course.begin(), course.end(), 
                     [](const Course &c1, const Course &c2){
                       if(c1.Section < c2.Section){
                         return true;
                       }else {
                         return false;
                       }
                     });  
          
    std::sort(course.begin(), course.end(), 
            [](const Course& c1, const Course& c2){
               if(c1.Number < c2.Number) {
                 return true;
               }
               else {
                 return false;
               }
            });  
  
          std::sort(course.begin(), course.end(), 
                     [](const Course &c1, const Course &c2){
                       if(c1.Dept < c2.Dept){
                         return true;
                       }else {
                         return false;
                       }
                     });         
}

void call_summary(College college) {
    string input;
    bool condition = true;
    sort_in_order(college);
  
    cout << "dept name, or all? ";
    cin >> input;
   
    if(input == "all") {
        for (Dept x : college.Depts){
        cout << x.Name << ":" << endl;
        call_print2(x);
        }
      }
      else{
        for (Dept x : college.Depts){
          if (input == x.Name){ 
            cout << x.Name << ":" << endl;
            call_print2(x);
            condition = false;
        }  
      }
  }
          if(condition) cout << "**dept not found" << endl;
}

void search_helper(Dept d, string input, bool& condition2) {
    string instructorPrefix = input;
    int courseNum;
    vector<Course> course; 
    
    stringstream ss(instructorPrefix);
    ss >> courseNum;

    if(ss.fail()) {
      course = FindCourses(d, instructorPrefix);
      if(!course.empty()){
      for (Course x : course) {  
          call_print3(x);
        }
      condition2 = false;
      }
    }
    else{
       course = FindCourses(d, courseNum);
       if(!course.empty()){
        for (Course x : course) {  
          call_print3(x);
       }
       condition2 = false;
       }
    }
  
   
}

void call_search(College college) {
    string input1, input2, value;
    bool condition1 = true;
    bool condition2 = true;
    sort_in_order(college);
  
    cout << "dept name, or all? ";
    cin >> input1;
    cout << "course # or instructor prefix? ";
    cin >> input2;

    for (Dept x : college.Depts) { 
      if(input1 == "all") {
         condition1 = false;
         search_helper(x, input2, condition2);
      }
      else if(input1 == x.Name){
         condition1 = false;
         search_helper(x, input2, condition2);
      }
    }

    if(condition1) cout << "**dept not found" << endl;
    if(condition2) cout << "**none found" << endl;
    
}

void satisfactory_helper(Dept d, vector<Course> &c) {
    
    for(Course x : d.Courses) {
      if(x.getGradingType() == 1) {
        c.push_back(x); 
      }
    }
}

void call_print4(vector<Course> c){
    for(Course x : c){
      cout << x.Dept << " " << x.Number << " (section " << x.Section << "): " << x.Instructor << endl;
      cout << " # students: " << x.getNumStudents() << endl;
      cout << " course type: satisfactory" << endl;
    }
}

void call_satisfactory(College college) {
    string input;
    bool condition = true;
    vector<Course> c1;
    vector<Course> c2;
    
    cout << "dept name, or all? ";
    cin >> input;
    

      if(input == "all"){
        for (Dept x : college.Depts){
          condition = false;
          satisfactory_helper(x, c1);
          sort_number_in_order(c1);        
        }
        call_print4(c1);
      }
      else{
        for (Dept x : college.Depts){
          if(input == x.Name){
            condition = false;
            satisfactory_helper(x, c2);

            sort_number_in_order(c2);
            call_print4(c2);
          }
        }
      }
    
  
    if(condition || (c1.empty() && c2.empty())) cout << "**none found" << endl;
}

void dfw_helper1(Dept d, vector<Course> &c, double input){
  int DFW, N;
  double courseDFW;  
  
  for(Course x : d.Courses) {
    courseDFW = GetDFWRate(x, DFW, N);  
    if(courseDFW > input) {
        c.push_back(x); 
      }
    }
}

void dfw_helper2(Dept d, string input2, vector<Course> &course, bool& condition2) {
    string input = input2;
    double dfw;
    
    stringstream ss(input);
    ss >> dfw;

    if(!ss.fail()) {
      dfw_helper1(d, course, dfw);
      sort_number_in_order(course);
      sort_back_order(course);
      if(!course.empty()){
      condition2 = false;
      }
    }
    else {
      condition2 = true;
    }

}

void call_dfw(College college){
    string input,input2;
    bool condition = true;
    bool condition2 = true;
    vector<Course> c1;
    vector<Course> c2;
    cout << "dept name, or all? ";
    cin >> input;
    cout << "dfw threshold? ";
    cin >> input2;
    
    if(input == "all"){
        for (Dept x : college.Depts){
          condition = false;
          dfw_helper2(x, input2, c1, condition2);  
        }
      
        for (Course y : c1) {  
          call_print3(y);
        }
    }
    else{
        for (Dept x : college.Depts) {
          if(input == x.Name) {
            condition = false;
            dfw_helper2(x, input2, c2, condition2);
          }
        }
      
        for (Course y : c2) {  
          call_print3(y);
        }
    }
  
    if(condition) cout << "**dept not found" << endl;
    if(condition2 || (c1.empty() && c2.empty())) cout << "**none found" << endl;
}

void letterB_helper1(Dept d, vector<Course> &c, double input){
  
  for(Course x : d.Courses) {
    GradeStats status = GetGradeDistribution(x);  
    if(status.PercentB > input) {
        c.push_back(x); 
      }
    }
}

void letterB_helper2(Dept d, string input2, vector<Course> &course, bool& condition2) {
    string input = input2;
    double dfw;
    
    stringstream ss(input);
    ss >> dfw;

    if(!ss.fail()) {
      letterB_helper1(d, course, dfw);
      sort_number_in_order(course);
      sort_back_order2(course);
      if(!course.empty()){
      condition2 = false;
      }
    }
    else {
      condition2 = true;
    }

}

void call_letterB(College college) {
    string input,input2;
    bool condition = true;
    bool condition2 = true;
    vector<Course> c1;
    vector<Course> c2;
    cout << "dept name, or all? ";
    cin >> input;
    cout << "letter B threshold? ";
    cin >> input2;
    
    if(input == "all"){
        for (Dept x : college.Depts){
          condition = false;
          letterB_helper2(x, input2, c1, condition2);  
        }
      
        for (Course y : c1) {  
          call_print3(y);
        }
    }
    else{
        for (Dept x : college.Depts) {
          if(input == x.Name) {
            condition = false;
            letterB_helper2(x, input2, c2, condition2);
          }
        }
      
        for (Course y : c2) {  
          call_print3(y);
        }
    }
  
    if(condition) cout << "**dept not found" << endl;
    if(condition2 || (c1.empty() && c2.empty())) cout << "**none found" << endl;
}

void call_print5(map<string,double> mymap) {
  
    std::vector<std::pair<string, double>> mapVector;
    // Insert entries
    for (auto iterator = mymap.begin(); iterator != mymap.end(); ++iterator) {
      mapVector.push_back(*iterator);
    }
  
    std::sort(mapVector.begin(), mapVector.end(),
               [](std::pair<string,double> const & a, std::pair<string,double> const & b){
               if(a.second > b.second){
                 return true;
               }
               else{
                 return false;
               }
           });
  
  for(const auto& pair : mapVector){
    cout << "Overall GPA for " << pair.first << " : " << pair.second << endl;
  } 
} 

void average_helper(Dept d, map<string,double> &mymap) {
  GradeStats grade = GetGradeDistribution(d);
  int number = 0;
  int p = 0;
  
  for(Course x : d.Courses) {
    p = (4 * grade.NumA + 3 * grade.NumB + 2 * grade.NumC + 1 * grade.NumD);
    
    if(x.getGradingType() == 0) {
      number = number + x.getNumStudents();
    }
  }
  
  double totalNumber = (double) number;
  double totalPoints = (double) p;
  double GPA = totalPoints / totalNumber;

  auto keyvaluepair = pair<string, double>(d.Name, GPA);
  mymap.insert(keyvaluepair);
}

void call_average(College college) {
    string input;
    bool condition = true;
    sort_in_order(college);
    map<string, double> mymap1;
    
    cout << "dept name, or all? ";
    cin >> input;
   
    if(input == "all") {
      condition = false;
        for (Dept x : college.Depts){
        average_helper(x, mymap1);
        }
        call_print5(mymap1);
      }
      else{
        //for (Dept x : college.Depts){
        //  if (input == x.Name){ 
        //    cout << x.Name << ":" << endl;
        //    call_print2(x);
        //    condition = false;
       // }  
     // }
  }
     if(condition) cout << "**dept not found" << endl;
}

int main()
{
    string filename;
    string input;
    bool condition = true;
    cout << std::fixed;
    cout << std::setprecision(2);
    

    //
    // 1. Input the filename and then the grade data:
    //
    cin >> filename;
    //filename = "fall-2018.csv";
    
    std::string delimiter = "-";
    std::string semester = filename.substr(0, filename.find(delimiter));
    //std::string year =  filename.substr(1, filename.find(delimiter)); 
  
    College college = InputGradeData(filename);
    sort_in_order(college);
    // 2. TODO: print out summary of the college
    // DEFINE your own functions
    //cout << filename << endl;
    if(semester == "fall") cout << "** College of Engineering, Fall 2018 **" << endl;
    if(semester == "spring") cout << "** College of Engineering++, Spring 2018 **" << endl;
    call_print1(college);
    cout << endl;
  
    //
    // 3. TODO: Start executing commands from the user:
    // DEFINE your own functions
    while(condition) {
      cout << "Enter a command> ";
      cin >> input;
      
      if(input == "summary") {
        call_summary(college);
      }
      else if(input == "search") {
        call_search(college);
      }
      else if(input == "satisfactory") {
        call_satisfactory(college);
      }
      else if(input == "dfw") {
        call_dfw(college);
      }
      else if(input == "letterB") {
        call_letterB(college);
      }
      else if(input == "average") {
        call_average(college);
      }
      else if(input == "#") {
        break;
      }
      else{
        cout << "**unknown command" << endl;
      }
      
    }

    //
    // done:
    //
    return 0;
}